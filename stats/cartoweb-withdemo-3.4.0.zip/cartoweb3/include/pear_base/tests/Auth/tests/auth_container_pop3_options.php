<?php

$options = array(
    'host'=>'mail.example.com',
    'port'=>'110'
);

$extra_options['username'] = 'test_user';
$extra_options['passwd'] = 'test_user';

?>
