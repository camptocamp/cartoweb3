<?php
/**
* Test for bug #541886
*
* Multiple @package or @subpackage tags causing a warning
* 
* @package tests 
* @subpackage blah
* @subpackage blahblah
*/
/**
* Test for bug #541886
*
* Multiple @package or @subpackage tags causing a warning
* 
* @package tests 
* @subpackage blah
* @subpackage blahblah
*/
class test_541886
{
}
?>
