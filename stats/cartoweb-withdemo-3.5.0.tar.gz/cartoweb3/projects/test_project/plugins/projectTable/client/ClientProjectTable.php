<?php
/**
 * @package Tests
 * @author Yves Bolognini <yves.bolognini@camptocamp.com>
 * @version $Id: ClientProjectTable.php,v 1.4 2005-05-11 07:33:33 yves Exp $
 */

/**
 * Plugin to test tables management
 * @package Tests
 */
class ClientProjectTable extends ClientPlugin 
                         implements ServerCaller {

    public function buildRequest() {
           
        return new ProjectTableRequest();
    }

    public function initializeResult($queryResult) {
        if (empty($queryResult))
            return;
        
        $tablesPlugin = $this->cartoclient->getPluginManager()->tables;
        $tablesPlugin->addTableGroups($queryResult->tableGroup);
    }

    public function handleResult($queryResult) {}                       
}

?>