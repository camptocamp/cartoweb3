var ol_textfont = "verdana, arial, sans-serif";
var ol_textsize="1";
var ol_captionsize="2";
var ol_fgcolor="#FFCC66";
var ol_bgcolor="#FF9900";
var ol_cgcolor="#FF9900";