<?php
$_ENV['CW3_PROJECT'] = 'demo';
require_once('client.php');
?>
