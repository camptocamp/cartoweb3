<?php
/**
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * @copyright 2005 Camptocamp SA
 * @package Plugins
 * @version $Id: ClientHello.php,v 1.11 2005/02/28 11:56:53 sypasche Exp $
 */

/**
 * Demo plugin, shows how to output messages and use sessions.
 * @package Plugins
 */
class ClientHello extends ClientPlugin
                  implements Sessionable, GuiProvider {

    const HELLO_INPUT = 'hello_input';

    /**
     * @var Logger
     */
    private $log;

    /**
     * @var string
     */
    private $message;

    /**
     * @var int
     */
    private $count;

    /** 
     * Constructor
     */
    public function __construct() {
        parent::__construct();

        $this->log =& LoggerManager::getLogger(__CLASS__);
    }

    /**
     * Retrieves count number from session.
     * @see Sessionable::loadSession()
     */
    public function loadSession($sessionObject) {
        $this->count = $sessionObject;
    }

    /**
     * Initializes session-saved var "count" to 0.
     * @see Sessionable::createSession()
     */
    public function createSession(MapInfo $mapInfo, InitialMapState $initialMapState) {
        $this->count = 0;
    }

    /**
     * Saves count number in session.
     * @see Sessionable::saveSession()
     */
    public function saveSession() {
        return $this->count;
    }
    
    /**
     * Increments count number and retrieves POST'ed message.
     * @see GuiProvider::handleHttpPostRequest()
     */
    public function handleHttpPostRequest($request) {
        $this->count = $this->count + 1;
        $this->message = @$_REQUEST[self::HELLO_INPUT];
    }

    /**
     * Not used.
     * @see GuiProvider::handleHttpGetRequest()
     */
    public function handleHttpGetRequest($request) {}

    /**
     * Draws plugins interface.
     * @see GuiProvider::renderForm()
     */
    public function renderForm(Smarty $template) {

        $template->assign('hello_active', true);
        $template->assign('hello_message', "message: " . $this->message . 
                          " count: " . $this->count);
    }
}
?>
