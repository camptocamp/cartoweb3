<?php

$options = 'users';

$extra_options['username'] = 'test_user';
$extra_options['passwd'] = 'test_user';

?>