<?php

$options = array(
    'host'=>'example.com',
    'port'=>'110'
);

$extra_options['username'] = 'yavo@example.com';
$extra_options['passwd'] = 'test';

?>