<?php
/**
* bug is fixed.  to test, remove this page-level docblock
* @package tests
*/
/**
* this page will not be shown in the package list and should be
*@package tests */
class bug557861
{
}
?>
