<?php
/** @package tests */
/**
* sdesc
*
* <pre>
*1234567890
* Test
* Test2
* </pre>
*/ 
function test_441287()
{
}

	/**
	* Check to see if we are stripping whitespace before the *
	* 
	* <pre>
	*1234567890
	* Test
	* 	Test2
	* </pre>
	*/
	function test_4412872()
	{
	}
?>
