<?php
/** @package tests */
/** include tests */
require_once $FORUM['LIB'] . '/classes/db/PearDb.php';
require PEAR . 'test' . 'me';
include('file.ext');
include 'file.ext';
include(PEAR . 'test' . 'me');
?>