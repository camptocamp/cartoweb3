<?php
/** @package tests */
/**
* Test description.
*
* anything said here
*
* @return array will return an array in the form:
* <pre>
* 0 => 10
* 1 => 20
* </pre>
*/
function test_441278()
{
return array(0 => 10, 1 => 20);
} 

?>
