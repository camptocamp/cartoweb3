<?php
/**
* @package tests
*/
/**
* func 1
*/
function func1()
{
}

function func2()
{
}

/**
* @see func1(), func2()
*/
function func3()
{
}
?>