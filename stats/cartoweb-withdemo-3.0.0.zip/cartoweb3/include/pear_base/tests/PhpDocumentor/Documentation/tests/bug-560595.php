<?php
/**
* @package tests
*/
/** 
this invalid docblock 
fails at cellog@users.sourceforge.net 
on the @sign 
**/
define('one','two');
?>