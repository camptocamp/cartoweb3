<?php
/**
* @package tests
* @package ignored
*/
/**
* @access public poopy
* @access public
* @access private
*/
function one()
{
}

/**
* @package tests
*/
class multipl
{
	/**
	* @var string first var
	* @var class stupid second one
	*/
	var $manyvars;
	
	/**
	* @return string first return
	* @return poopy second return
	*/
	function func()
	{
	}
}
?>