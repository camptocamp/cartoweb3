<?php
$_ENV['CW3_PROJECT'] = 'demoEdit';
require_once('client.php');
?>
