<?php
$_ENV['CW3_PROJECT'] = 'demoPlugins';
require_once('client.php');
?>
