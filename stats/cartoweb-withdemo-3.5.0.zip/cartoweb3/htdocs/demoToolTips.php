<?php
$_ENV['CW3_PROJECT'] = 'demoToolTips';
require_once('client.php');
?>
