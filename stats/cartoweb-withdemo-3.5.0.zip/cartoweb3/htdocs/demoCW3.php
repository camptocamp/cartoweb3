<?php
$_ENV['CW3_PROJECT'] = 'demoCW3';
require_once('client.php');
?>
