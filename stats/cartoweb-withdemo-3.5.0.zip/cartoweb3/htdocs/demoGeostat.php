<?php
$_ENV['CW3_PROJECT'] = 'demoGeostat';
require_once('client.php');
?>
