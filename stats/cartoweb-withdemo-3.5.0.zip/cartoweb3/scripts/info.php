<?php
/**
 * @package Htdocs
 * @version $Id: info.php,v 1.3 2006-11-17 17:01:29 asaunier Exp $
 */

if (!extension_loaded('mapscript') && 
    !dl('php_mapscript.' . PHP_SHLIB_SUFFIX)) {
    print("WARNING: can't load mapscript library");
}

phpinfo();

?>
