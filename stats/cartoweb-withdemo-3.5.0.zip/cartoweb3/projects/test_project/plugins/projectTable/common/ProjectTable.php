<?php
/**
 * @package Tests
 * @author Yves Bolognini <yves.bolognini@camptocamp.com>
 * @version $Id: ProjectTable.php,v 1.4 2007-05-14 09:42:22 sypasche Exp $
 */

/**
 * @package Tests
 */
class ProjectTableRequest extends CwSerializable {

    public function unserialize($struct) {
    }
}

/**
 * @package Tests
 */
class ProjectTableResult extends CwSerializable {

    /**
     * @var Table
     */
    public $tableGroup;

    public function unserialize($struct) {
        $this->tableGroup = self::unserializeObject($struct, 'tableGroup', 'TableGroup');
    }
}

?>
