<?php
/**
 * @package Tests
 * @version $Id: ServerProjectLocation.php,v 1.6 2007-05-14 09:42:22 sypasche Exp $
 */

/**
 * @package Tests
 */
class ServerProjectLocation extends ServerLocation {

    public function useExtendedResult() {
        return true;
    }

    public function useExtendedRequest() {
        return true;
    }

    /**
     * @see CoreProvider::handleCorePlugin()
     */
    public function handleCorePlugin($requ) {

        $projectResult = new ProjectLocationResult();
        if (isset($requ->locationRequest)) {
            $projectResult->locationResult = 
                parent::handleCorePlugin($requ->locationRequest);
        }
        $projectResult->projectResult = str_rot13($requ->projectRequest);
        
        return $projectResult;
    }

    public function replacePlugin() {
        return 'location';
    }
}

?>
