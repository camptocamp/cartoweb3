<?php
/**
 * Distribution Class
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * @copyright 2006 Camptocamp SA
 * @package DataManagement
 * @version $Id: Distribution.php,v 1.4 2007-06-06 15:36:37 dcorpataux Exp $
 */
 
/**
 * Bin and Classification classes are required
 */
require_once('Bin.php');
require_once('Classification.php');


/**
 * This class gives summary about a distribution without passing the entire
 * dataset.
 * @package DataManagement
 */
class DistributionSummary {
    public $nbVal;
    public $minVal;
    public $maxVal;
    public $meanVal;
    public $stdDevVal;
    
    public function __construct($distribution) {
        $this->nbVal = $distribution->getNbVal();
        $this->minVal = $distribution->getMin();
        $this->maxVal = $distribution->getMax();
        $this->meanVal = $distribution->getMean();
        $this->stdDevVal = $distribution->getStdDev();
    }
}

/**
 * @package DataManagement
 */
class Distribution {
    
    const CLASSIFY_WITH_BOUNDS = 0;
    const CLASSIFY_BY_EQUAL_INTERVALS = 1;
    const CLASSIFY_BY_QUANTILS = 2;
    const CLASSIFY_BY_MODES = 3;
    
    /**
     * This array contains values of the distribution.
     */ 
    protected $values = array();
    
     /**
      * @var int
      */
    protected $nbVal;
    
    protected $minVal;
    
    protected $maxVal;
    
    protected $meanVal;
    
    protected $stdDevVal;
    
    
    /**
     * @param array $values All values must be passed at construction
     * @return void
     */
    public function __construct ($values) {
        $this->values = $values;
        $this->nbVal = count($this->values);
        $this->minVal = $this->nbVal ? min($this->values) : 0;
        $this->maxVal = $this->nbVal ? max($this->values) : 0;
        $this->meanVal = $this->nbVal ? array_sum($this->values)/$this->nbVal : 0;
        
        $stdDevNum = 0;
        foreach($values as $val) {
            $stdDevNum += pow($val - $this->meanVal,2);
        }
        if ($this->nbVal > 1) {
            $this->stdDevVal = sqrt($stdDevNum/($this->nbVal-1));
        } else {
            $this->stdDevVal = NULL;
        }
    }
    
    /**
     * @return mixed
     */
    public function getValues() {
        return $this->values;
    }
    
    /**
     * @return int
     */
    public function getNbVal() {
        return $this->nbVal;
    }
    
    /**
     * @return mixed
     */
    public function getMin() {
        return $this->minVal;
    }
    
    /**
     * @return mixed
     */
    public function getMax() {
        return $this->maxVal;
    }
    
    /**
     * @return mixed
     */
    public function getMean() {
        return $this->meanVal;
    }
    
    /**
     * @return mixed
     */
    public function getStdDev() {
        return $this->stdDevVal;
    }
    
    
    /**
     * @param mixed[] $bounds Bounds of classes
     * We suppose that every value is within min($bounds)
     * and max($bounds)
     * @return Classification
     */
    public function classifyWithBounds($bounds) {
        $bins = array();
        $binCount = array();
        $sortedValues = $this->values;
        $nbBins = count($bounds)-1;
        sort($sortedValues);
        
        for($i=0;$i<($nbBins);$i++) {
            $binCount[$i] = 0;
        }
        
        for($i=0;$i<($nbBins-1);) {
            if(isset($sortedValues[0]) && $sortedValues[0] < $bounds[$i+1]) {
                $binCount[$i]=$binCount[$i] + 1;
                array_shift($sortedValues);
            } else {
                $i++;
            }
        }
        $binCount[$nbBins-1] = $this->nbVal-array_sum($binCount);
        
        for($i=0;$i<($nbBins);$i++) {
            $label = $bounds[$i] . '-' . $bounds[$i+1];
            $bins[$i] = new Bin($binCount[$i], $label, $bounds[$i],
                $bounds[$i+1], $i==($nbBins-1));
        }
        
        return new Classification($bins);        
    }
    
    /**
     * @return Classification
     */
    public function classifyByEqIntervals($nbBins) {
        $bounds = array();
        
        for($i=0; $i<=$nbBins; $i++) {
            $bounds[$i] = $this->minVal + 
                $i*($this->maxVal-$this->minVal)/$nbBins;
        }
        
        return $this->classifyWithBounds($bounds);           
    }
   
    /**
     * @return Classification
     */
    public function classifyByQuantils($nbBins) {
        $values = $this->values;
        sort($values);
        $binSize = round(count($this->values) / $nbBins);
        
        $bounds = array();
        $binLastValPos = $binSize == 0 ? 0 : ($binSize);
        if (count($values) > 0) {
            $bounds[0] = $values[0]; 
            for ($i = 1 ; $i < $nbBins ; $i++) {
                $bounds[$i] = $values[$binLastValPos]; 
                $binLastValPos += $binSize;
            }
            $bounds[] = $values[count($values)-1];
        }
        return $this->classifyWithBounds($bounds);
    }
    
    /**
     * Returns n-1 classes for the n-1 modes of the distribution and an
     * "other" class.
     * This method will fail if type is different of int or string
     * You may disable the other class
     * @param int $nbBins Number of classes required
     * @param bool $ClassOther Enable "Other" class (default)
     * @return Classification
     */
    public function classifyByModes($nbBins, $ClassOther=true) {
        $countValues = array_count_values($this->values);
        arsort($countValues);
        $countValuesId = array_keys($countValues);
        $countValuesNb = array_values($countValues);
        
        $bins = array();
        $sum = 0;
        for($i=0;$i<($nbBins-1);$i++) {
            $bins[] = new Bin($countValuesNb[$i], $countValuesId[$i]);
            $sum += $countValuesNb[$i];
        }
        if($ClassOther == true) {
            $bins[] = new Bin($this->nbVal-$sum,'Others');
        } else {
            $bins[] = new Bin($countValuesNb[$nbBins-1], 
                $countValuesId[$nbBins-1]);
        }
        
        return new Classification($bins);
    }
    
    /**
     * @return integer Maximal number of classes according to the Sturge's rule
     */
     public function sturgesRule() {
         return intval(floor(1 + 3.3 * log($this->nbVal,10.0)));
     }
     
     /**
     * @return integer Maximal number of classes according to the Yule's rule
     */
     public function yulesRule() {
         return intval(floor(2.5*pow($this->nbVal,0.25)));
     }
    
    /**
     * This function calls the appropriate classifyBy... function.
     * The name of classification methods are defined by class constants
     * @param integer $method Method name constant as define in this class
     * @param integer $nbBins Number of classes
     * @param array $bounds Bounds of classification
     * @return Classification
     */
    public function classify(
            $method = Distribution::CLASSIFY_BY_EQUAL_INTERVALS, 
            $nbBins = NULL,
            $classOther = true,
            $bounds = array()) {
        if(is_null($nbBins)) {
            $nbBins = $this->sturgesRule();
        }
        switch($method) {
        case Distribution::CLASSIFY_WITH_BOUNDS :
            $classification = $this->classifyWithBounds($bounds);
            break;
        case Distribution::CLASSIFY_BY_EQUAL_INTERVALS :
            $classification = $this->classifyByEqIntervals($nbBins);
            break;
        case Distribution::CLASSIFY_BY_QUANTILS :
            $classification = $this->classifyByQuantils($nbBins);
            break;
        case Distribution::CLASSIFY_BY_MODES :
            $classification = $this->classifyByModes($nbBins, $classOther);
        }
        
        return $classification;
    }
}

?>