<?php
/**
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * @copyright 2005 Camptocamp SA
 * @package Tests
 * @version $Id: ColorTest.php,v 1.1 2007-03-30 12:09:45 dcorpataux Exp $
 */

require_once 'PHPUnit2/Framework/TestCase.php';
require_once '../Color.php';


class ColorTest extends PHPUnit2_Framework_TestCase {
    
    protected function assertEqualRgbColors($firstColor,$secondColor) {
        $this->assertEquals(floatval($firstColor->getColorRgb()->getRedLevel()),
            floatval($secondColor->getColorRgb()->getRedLevel()), '', $delta = 1.1);
        $this->assertEquals(floatval($firstColor->getColorRgb()->getGreenLevel()),
            floatval($secondColor->getColorRgb()->getGreenLevel()), '', $delta = 1.1);
        $this->assertEquals(floatval($firstColor->getColorRgb()->getBlueLevel()),
            floatval($secondColor->getColorRgb()->getBlueLevel()), '', $delta = 1.1);
    }
    
    protected function assertEqualHsvColors($firstColor,$secondColor) {
        $this->assertEquals(floatval($firstColor->getColorHsv()->getHueLevel()),
            floatval($secondColor->getColorHsv()->getHueLevel()), '', $delta = 1.1);
        $this->assertEquals(floatval($firstColor->getColorHsv()->getSaturationLevel()),
            floatval($secondColor->getColorHsv()->getSaturationLevel()), '', $delta = 0.011);
        $this->assertEquals(floatval($firstColor->getColorHsv()->getValueLevel()),
            floatval($secondColor->getColorHsv()->getValueLevel()), '', $delta = 0.011);
    }
    
    protected function setUp() {
        $this->rgbBlack = new ColorRgb(0,0,0);
        $this->rgbWhite = new ColorRgb(255,255,255);
        $this->rgbGray = new ColorRgb(100,100,100);
        $this->rgbColorA = new ColorRgb(82,47,176);
        $this->rgbColorB = new ColorRgb(104,205,43);
        $this->hsvBlack = new ColorHsv(0.0,0.0,0.0);
        $this->hsvWhite = new ColorHsv(0.0,0.0,1.0);
        $this->hsvGray = new ColorHsv(0.0,0.0,0.39);
        $this->hsvColorA = new ColorHsv(256.0,0.73,0.69);
        $this->hsvColorB = new ColorHsv(97.0,0.79,0.80);
    }
    
    public function testRgb2Hsv() {
        $this->assertEqualHsvColors($this->rgbBlack,$this->hsvBlack);
        $this->assertEqualHsvColors($this->rgbWhite,$this->hsvWhite);
        $this->assertEqualHsvColors($this->rgbGray,$this->hsvGray);
        $this->assertEqualHsvColors($this->rgbColorA,$this->hsvColorA);
        $this->assertEqualHsvColors($this->rgbColorB,$this->hsvColorB);
    }
    

    public function testHsv2Rgb() {
        $this->assertEqualRgbColors($this->rgbBlack,$this->hsvBlack);
        $this->assertEqualRgbColors($this->rgbWhite,$this->hsvWhite);
        $this->assertEqualRgbColors($this->rgbGray,$this->hsvGray);
        $this->assertEqualRgbColors($this->rgbColorA,$this->hsvColorA);
        $this->assertEqualRgbColors($this->rgbColorB,$this->hsvColorB);
  
    }
    
     public function testColorEquals() {
        $this->assertTrue($this->rgbBlack->equals($this->rgbBlack));
        $this->assertTrue($this->rgbBlack->equals($this->hsvBlack));
        $this->assertTrue($this->hsvColorA->equals($this->hsvColorA));
        $this->assertFalse($this->hsvWhite->equals($this->rgbColorB));
    }
}

?>