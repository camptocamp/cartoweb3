<?php
/**
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * @copyright 2005 Camptocamp SA
 * @package Tests
 * @version $Id: DistributionTest.php,v 1.1 2007-03-30 12:09:45 dcorpataux Exp $
 */

require_once 'PHPUnit2/Framework/TestCase.php';
require_once '../Distribution.php';


class DistributionTest extends PHPUnit2_Framework_TestCase {
    
    public function testNumericUnivariateStats() {
        
        $a1 = array(1,2,3,4,5,6,7,8,9);
        $distrib = new Distribution($a1);
        $this->assertEquals(1,$distrib->getMin());
        $this->assertEquals(9,$distrib->getMax());
        $this->assertEquals(5,$distrib->getMean());
        $this->assertEquals(sqrt(7.5), $distrib->getStdDev());
        $this->assertEquals(9, $distrib->getNbVal());
        $this->assertEquals(array(1,2,3,4,5,6,7,8,9), $distrib->getValues());
        
    }
    
    public function testClassifyWithBounds() {
        $a2 = array(0,1,2,10,11,100,200,300,1000,1000);
        $bounds = array(0,10,100,1000);
        $distrib = new Distribution($a2);
        $classification = $distrib->classifyWithBounds($bounds);
        $nbValues = $classification->getNbValArray();
        $this->assertEquals(3,count($nbValues));
        $this->assertEquals(3,$nbValues[0]);
        $this->assertEquals(2,$nbValues[1]);
        $this->assertEquals(5,$nbValues[2]);
    }
    
    public function testClassifyByEqIntervals() {
        $a1 = array(0.0,1.0,2.0,2.0,3,4,5,7,8,10,11,11.5,12.0);
        $distrib = new Distribution($a1);
        $classification = $distrib->classifyByEqIntervals(4);
        $nbValues = $classification->getNbValArray();
        $this->assertEquals(4,count($nbValues));
        $this->assertEquals(4,$nbValues[0]);
        $this->assertEquals(3,$nbValues[1]);
        $this->assertEquals(2,$nbValues[2]);
        $this->assertEquals(4,$nbValues[3]);
    }

    public function testClassifyByQuantils() {
        $a1 = array(0.0,1.0,2.0,2.0,3,4,5,7,8,10,11,11.5,12.0);
        $distrib = new Distribution($a1);
        $classification = $distrib->classifyByQuantils(4);
        $nbValues = $classification->getNbValArray();
        $this->assertEquals(4,count($nbValues));
        $this->assertEquals(2,$nbValues[0]);
        $this->assertEquals(4,$nbValues[1]);
        $this->assertEquals(3,$nbValues[2]);
        $this->assertEquals(4,$nbValues[3]);
        
        $a2 = range(1,12);
        $distrib = new Distribution($a2);
        $classification = $distrib->classifyByQuantils(4);
        $nbValues = $classification->getNbValArray();
        $this->assertEquals(4,count($nbValues));
        $this->assertEquals(3,$nbValues[0]);
        $this->assertEquals(3,$nbValues[1]);
        $this->assertEquals(3,$nbValues[2]);
        $this->assertEquals(3,$nbValues[3]);
        
    }
    
    public function testClassifyByModes() {
        $a1 = array(1,1,1,1,2,3,3,3,4,4,7,8);
        $distrib1 = new Distribution($a1);
        $classification = $distrib1->classifyByModes(3);
        $nbValues = $classification->getNbValArray();
        $labels = $classification->getLabelsArray();
        $this->assertEquals(3,count($nbValues));
        $this->assertEquals(4,$nbValues[0]);
        $this->assertEquals(3,$nbValues[1]);
        $this->assertEquals(5,$nbValues[2]);
        $this->assertEquals(1,$labels[0]);
        $this->assertEquals(3,$labels[1]);
        $this->assertEquals('Others',$labels[2]);
        
        $a2 = array('bonjour','salut','allo','bonsoir','salut','salut','salut',
                'allo','allo');
        $distrib2 = new Distribution($a2);
        $classification = $distrib2->classifyByModes(2, false);
        $nbValues = $classification->getNbValArray();
        $labels = $classification->getLabelsArray();
        $this->assertEquals(2,count($nbValues));
        $this->assertEquals(4,$nbValues[0]);
        $this->assertEquals(3,$nbValues[1]);
        $this->assertEquals('salut',$labels[0]);
        $this->assertEquals('allo',$labels[1]);
    }
    
    public function testClassifyByModes2() {
        $a1 = array(1,1,1,1,2,3,3,3,4,4,7,8);
        $distrib1 = new Distribution($a1);
        $classification = $distrib1->classify(
            $method = Distribution::CLASSIFY_BY_MODES,
            $nbBins =3);
        $nbValues = $classification->getNbValArray();
        $labels = $classification->getLabelsArray();
        $this->assertEquals(3,count($nbValues));
        $this->assertEquals(4,$nbValues[0]);
        $this->assertEquals(3,$nbValues[1]);
        $this->assertEquals(5,$nbValues[2]);
        $this->assertEquals(1,$labels[0]);
        $this->assertEquals(3,$labels[1]);
        $this->assertEquals('Others',$labels[2]);
    }
    
    public function testSturgesRule() {
        $a1 = range(1,10);
        $a2 = range(1,100);
        $a3 = range(1,1000);
        $distrib1 = new Distribution($a1);
        $distrib2 = new Distribution($a2);
        $distrib3 = new Distribution($a3);
        $this->assertEquals(4,$distrib1->sturgesRule());
        $this->assertEquals(7,$distrib2->sturgesRule());
        $this->assertEquals(10,$distrib3->sturgesRule());
    }
    
    public function testYulesRule() {
        $a1 = range(1,10);
        $a2 = range(1,100);
        $a3 = range(1,1000);
        $distrib1 = new Distribution($a1);
        $distrib2 = new Distribution($a2);
        $distrib3 = new Distribution($a3);
        $this->assertEquals(4,$distrib1->yulesRule());
        $this->assertEquals(7,$distrib2->yulesRule());
        $this->assertEquals(14,$distrib3->yulesRule());
    }

    public function testOneDataDistrib() {
        $a = array(1);
        $distrib = new Distribution($a);
        $classification = $distrib->classifyByQuantils($distrib->sturgesRule());
        $labels = $classification->getLabelsArray();
        $this->assertEquals(1,count($classification->getNbValArray()));
        $this->assertEquals('1-1',$labels[0]);
    }
	
}

?>
