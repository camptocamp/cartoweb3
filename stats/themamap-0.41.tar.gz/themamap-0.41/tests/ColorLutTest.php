<?php
/**
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * @copyright 2005 Camptocamp SA
 * @package Tests
 * @version $Id: ColorLutTest.php,v 1.1 2007-03-30 12:09:45 dcorpataux Exp $
 */

require_once 'PHPUnit2/Framework/TestCase.php';
require_once 'PHPUnit2/Framework/IncompleteTestError.php';
require_once '../ColorLut.php';


class ColorLutTest extends PHPUnit2_Framework_TestCase {
    
    protected function setUp() {
        $this->rgbColorA = new ColorRgb(226,53,39);
        $this->rgbColorB = new ColorRgb(54,38,211);
        $this->hsvColorA = new ColorHsv(256.0,0.73,0.69);
        $this->hsvColorB = new ColorHsv(97.0,0.79,0.80);
        $this->hsvColorC = new ColorHsv(100.0,0.50,0.50);
        $this->hsvColorD = new ColorHsv(200.0,0.80,0.80);
        
    }
    
    public function testGetColorsArrayByRgbInterpolation() {
        $initialColors = array($this->rgbColorA,$this->rgbColorB);
        $colorLut = new ColorLut($initialColors);
        $resultRgb = $colorLut->getColorsArrayByRgbInterpolation(3);
        $this->assertTrue($this->rgbColorA->equals($resultRgb[0]));
        $this->assertTrue($this->rgbColorB->equals($resultRgb[2]));
    }
    
    public function testGetColorsArrayByHsvInterpolation() {
        $initialColors = array($this->hsvColorA,$this->hsvColorB);
        $colorLut = new ColorLut($initialColors);
        $resultHsv = $colorLut->getColorsArrayByRgbInterpolation(3);
        $this->assertTrue($this->hsvColorA->equals($resultHsv[0]));
        $this->assertTrue($this->hsvColorB->equals($resultHsv[2]));
        $initialColors = array($this->hsvColorC,$this->hsvColorD);
        $colorLut = new ColorLut($initialColors);
        $resultHsv = $colorLut->getColorsArrayByHsvInterpolation(3,false);
        $color1 = new ColorHsv(150.0,0.65,0.65);
        $this->assertTrue($color1->equals($resultHsv[1]));
        $resultHsv2 = $colorLut->getColorsArrayByHsvInterpolation(3,true);
        $color2 = new ColorHsv(330.0,0.65,0.65);
        $this->assertTrue($color1->equals($resultHsv[1]));
    }
    
    public function testGetColorsHsvArrayWithMaxDifference() {
        $initialColors = array($this->hsvColorA,$this->hsvColorB);
        $colorLut = new ColorLut($initialColors);
        $resultHsv = $colorLut->getColorsArrayByRgbInterpolation(3);
        $this->assertTrue($this->hsvColorA->equals($resultHsv[0]));
    }
    
    public function testOneColorRequestRgb() {
        $initialColors = array(new ColorRgb(0,0,0), new ColorRgb(0,0,0));
        $colorLut = new ColorLut($initialColors);
        $rgbInterp = $colorLut->getColorsArrayByRgbInterpolation(1);
        $this->assertEquals(1,count($rgbInterp));
    }
    
    public function testOneColorRequestHsv() {
        $initialColors = array(new ColorRgb(0,0,0), new ColorRgb(0,0,0));
        $colorLut = new ColorLut($initialColors);
        $hsvInterp = $colorLut->getColorsArrayByHsvInterpolation(1);
        $this->assertEquals(1,count($hsvInterp));
    }
    
    public function testOneColorRequestMaxDifference() {
        $initialColors = array(new ColorRgb(0,0,0), new ColorRgb(0,0,0));
        $colorLut = new ColorLut($initialColors);
        $maxInterp = $colorLut->getColorsHsvArrayWithMaxDifference(1);
        $this->assertEquals(1,count($maxInterp));
    }
}

?>