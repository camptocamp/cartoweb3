<?php
/**
 * Bin Class
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * @copyright 2006 Camptocamp SA
 * @package DataManagement
 * @version $Id: Classification.php,v 1.2 2007-06-06 15:36:37 dcorpataux Exp $
 */

/**
 * Bin Class
 */
require_once('Bin.php');

/**
 * Classification summarize a Distribution by regrouping data within several Bins.
 * @package DataManagement
 */
class Classification {
    
    /**
     * @var Bins[]
     */
    protected $bins = array();
    
    
    /**
     * @param Bin[] $bins An array of Bins
     */
    public function __construct($bins) {
        $this->bins = $bins;
    }
    
    /**
     * @return int[] Number of values in every bins
     */
    public function getNbValArray() {
        $values = array();
        foreach($this->bins as $b) {
            array_push($values, $b->getNbVal());
        }
        return $values;
    }
    
    /**
     * @return array Label of every bins
     */
    public function getLabelsArray() {
        $labels = array();
        foreach($this->bins as $b) {
            array_push($labels, $b->getLabel());
        }
        
        return $labels;
    }
    
    /**
     * @return numeric[] Return bounds of bins
     */
    public function getBoundsArray() {
        $bounds = array();
        foreach($this->bins as $b) {
            array_push($bounds, $b->getLowerBound());
        }
        if (count($this->bins) > 0) {
            array_push($bounds,end($this->bins)->getUpperBound());
        }
        
        return $bounds;
    }
    
    public function getBins() {
    	return $this->bins;
    }
     
}
    
?>