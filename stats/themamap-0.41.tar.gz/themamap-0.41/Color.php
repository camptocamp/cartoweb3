<?php
/**
 * Colors related classes
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * @copyright 2006 Camptocamp SA
 * @package Color
 * @version $Id: Color.php,v 1.3 2007-05-30 10:15:10 dcorpataux Exp $
 */



/**
 * An abstract representation of color
 * @package Color
 */
abstract class Color {

    /**
     * @return ColorRgb
     */
    abstract public function getColorRgb();

    /**
     * Using Nicolas Ribot algorithm
     * @return ColorHsb
     */
    abstract public function getColorHsv();

    /**
     * @return ColorCymk
     * // TODO: Does not exist yet !
     */
    public function getColorCymk() {
        $colorRgb = $this->getColorRgb();
        return $colorCymk;
    }
    
    /**
     * @return int RGB hex color value
     */
    public function getRgbHexString() {
    	$colorRgb = $this->getColorRgb();
        $hexString = sprintf("%02x",$colorRgb->getRedLevel());
        $hexString .= sprintf("%02x",$colorRgb->getGreenLevel());
        $hexString .= sprintf("%02x",$colorRgb->getBlueLevel());
        return $hexString;
    }
    
    /**
     * @return bool True if colors are the same
     */
     public function equals($color) {
         return $this->getColorRgb()->getRedLevel() ==
            $color->getColorRgb()->getRedLevel() &&
            $this->getColorRgb()->getGreenLevel() ==
            $color->getColorRgb()->getGreenLevel() &&
            $this->getColorRgb()->getBlueLevel() ==
            $color->getColorRgb()->getBlueLevel();
     }
}

/**
 * RGB Representation of color
 * @package Color
 */
class ColorRgb extends Color {
    
    /**
     * @var int level [0..255]
     */
    protected $redLevel;
    protected $greenLevel;
    protected $blueLevel;
    
    
    public function __construct($red = 0, $green = 0, $blue = 0) {
        $this->redLevel = intval($red);
        $this->greenLevel = intval($green);
        $this->blueLevel = intval($blue);
    }
    
    public function getColorHsv() {
        $hue = 0.0;
        $saturation = 0.0;
        $value = 0.0;
        
        $red = $this->getRedLevel()/255.0;
        $blue = $this->getBlueLevel()/255.0;
        $green = $this->getGreenLevel()/255.0;
        
        $rgbMax = max($this->getRgbArray())/255.0;
        $rgbMin = min($this->getRgbArray())/255.0;
        
        if($rgbMax < (1/256.0)) {
            return new ColorHsv(0.0, 0.0, 0.0);
        } else {
            $saturation = ($rgbMax - $rgbMin)/$rgbMax;
            $value = $rgbMax;
        } 
        
        if ($red == $rgbMax && !($blue == $rgbMax && $green == $rgbMax)) {
            $hue = ($green - $blue)/($rgbMax - $rgbMin);
        } else if ($green == $rgbMax && !($red == $rgbMax && $green == $rgbMax)) {
            $hue = 2 + ($blue - $red)/($rgbMax - $rgbMin);
        } else if (!($green == $rgbMax && $red == $rgbMax)) {
            $hue = 4 + ($red - $green)/($rgbMax - $rgbMin);
        } else {
            //Undefined
        }
        
        $hue *= 60;
        if ($hue < 0) {$hue += 360;}
        
        return new ColorHsv((float)$hue, (float)$saturation, (float)$value);
    }

    /**
     * @see Color::getColorRgb()
     */
    public function getColorRgb() {
        return $this;    	
    }
    
    public function getRedLevel() {
    	return $this->redLevel;
    }    

    public function getGreenLevel() {
        return $this->greenLevel;
    }    

    public function getBlueLevel() {
        return $this->blueLevel;
    }
    
    public function getRgbArray() {
        return array($this->redLevel, $this->greenLevel,
         $this->blueLevel);
    }

    static public function hex2rgbArray($rgbHexString) {
        if($rgbHexString{0} == '#') {
            $rgbHexString = substr($rgbHexString,1);
        }
        $rgbArray = array(
            intval(substr($rgbHexString,0,2),16),
            intval(substr($rgbHexString,2,2),16),
            intval(substr($rgbHexString,4,2),16)
        );
        foreach ($rgbArray as $hexLevel) {
        	if ($hexLevel < 0 || $hexLevel > 255 ) {
        		throw new Exception("Invalid rgb hex color string: $rgbHexString");
        	}
        }        
        return $rgbArray;
    }    

    /**
     * Sets the color from a color hex string 
     * @param string Hex color string (format: #rrggbb)
     */
    public function setFromHex($rgbHexString) {        
        $rgbArray = self::hex2rgbArray($rgbHexString);
        $this->redLevel = $rgbArray[0];
        $this->greenLevel = $rgbArray[1];
        $this->blueLevel = $rgbArray[2];
    }
}

/**
 * HSV Representation of color
 * @package Color
 */
class ColorHsv extends Color {

    /**
     * @var float hue (0-360)
     */
    protected $hueLevel;
    /**
     * @var float saturation (0-1)
     */
    protected $saturationLevel;
    /**
     * @var float value (0-1)
     */
    protected $valueLevel;
    
    public function __construct($hue, $saturation, $value) {
        $this->hueLevel = (float)$hue;
        $this->saturationLevel = (float)$saturation;
        $this->valueLevel = (float)$value;
    }

        /**
     * @see Color::getColorRgb()
     */
    public function getColorRgb() {
        
        //Transformation parameters
        $f;$p;$q;$t;
        //There are 6 cases
        $case;
        
        $red;$green;$blue;
        
        $hue = $this->hueLevel;
        $saturation = $this->saturationLevel;
        $value = $this->valueLevel;
        
        if ($saturation == 0) {
            $red = $value;
            $green = $value;
            $blue = $value;
        } else {
            $hue == 360.0 ? 60.0 : $hue;
            $case = intval(floor($hue/60)) % 6;
            $f = $hue/60 - $case;
            $p = $value * (1 - $saturation);
            $q = $value * (1 - ($saturation * $f));
            $t = $value * (1 - ($saturation * (1 - $f)));
            
            switch($case) {
                case 0:
                    $red=$value; $green=$t; $blue=$p;
                break;
                case 1:
                    $red=$q; $green=$value; $blue=$p;
                break;
                case 2:
                    $red=$p; $green=$value; $blue=$t;
                break;
                case 3:
                    $red=$p; $green=$q; $blue=$value;
                break;
                case 4:
                    $red=$t; $green=$p; $blue=$value;
                break;
                case 5:
                    $red=$value; $green=$p; $blue=$q;
                break;
            }
        }
            
        return new ColorRgb(intval($red*255),intval($green*255),intval($blue*255));
    }
    
    /**
     * @see Color::$getColorHsv()
     */
    public function getColorHsv() {
        return $this;
    }
    
    public function getHueLevel() {
        return $this->hueLevel;
    }    

    public function getSaturationLevel() {
        return $this->saturationLevel;
    }    

    public function getValueLevel() {
        return $this->valueLevel;
    }
    
    public function getHsvArray() {
        return array($this->hueLevel, $this->saturationLevel,
            $this->valueLevel);
    }

}

/**
 * HSV Representation of color
 * @package Color
 */
class ColorCymk extends Color {

    /**
     * @var int level [0..255]
     */
    protected $cyanLevel;
    protected $yellowLevel;
    protected $magentaLevel;
    protected $blackLevel;

    public function getCyanLevel() {
        return $this->cyanLevel;
    }    

    public function getYellowLevel() {
        return $this->yellowLevel;
    }    

    public function getMagentaLevel() {
        return $this->magentaLevel;
    }    

    public function getBlackLevel() {
        return $this->blackLevel;
    }    

    /**
     * @see Color::getColorRgb()
     */
    public function getColorRgb() {
        // TODO
    }
    
    public function getColorHsv() {
        // TODO
    }

    /**
     * @see Color::getColorCymk()
     */
    public function getColorCymk() {
        return this;        
    }
    
}
    
?>