<?php
/**
 * Bin Class
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * @copyright 2006 Camptocamp SA
 * @package DataManagement
 * @version $Id: Bin.php,v 1.1 2007-03-30 12:09:45 dcorpataux Exp $
 */

/**
 * Bin is category of the Classification.
 * When they are defined, $lowerBound is within the class
 * and $upperBound is outside de the class.
 * @package DataManagement
 */
class Bin {
    
    protected $label;
    
    /**
     * @var int
     */
    protected $nbVal;
    
    /**
     * @var numeric
     */
    protected $lowerBound;
    
    /**
     * @var numeric
     */
    protected $upperBound;
    
    /**
     * For the last bin, $upperBound is within the bin
     * @var bool
     */
    protected $isLast = false;
    
    public function __construct ($nbVal, $label=NULL, 
        $lowerBound=NULL, $upperBound=NULL, $isLast=false) {
        
        $this->nbVal = $nbVal;
        $this->label = $label;
        $this->lowerBound = $lowerBound;
        $this->upperBound = $upperBound;
        $this->isLast = $isLast;
        
    }
    
    /**
     * @return int
     */
    public function getNbVal() {
        return $this->nbVal;
    }
    
    /**
     * @return mixed
     */
    public function getLowerBound() {
        return $this->lowerBound;
    }
    
    /**
     * @return mixed
     */
    public function getUpperBound() {
        return $this->upperBound;
    }
    
    /**
     * @return bool
     */
    public function isLastBin() {
        return $this->isLast;
    }
    
    /**
     * @return mixed
     */
    public function getLabel() {
        return $this->label;
    }

    public function setLabel($name) {
        $this->label = $name;
    }
    
}
    
?>