<?php
/**
 * Colors look-up table class
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * @copyright 2006 Camptocamp SA
 * @package Color
 * @version $Id: ColorLut.php,v 1.1 2007-03-30 12:09:45 dcorpataux Exp $
 */


/**
 * Color Class
 */
require_once('Color.php');

/**
 * Color Look-up Table Class
 * @package Color
 */
class ColorLut {
    
    const METHOD_RGB_INTERPOLATION = 1;
    const METHOD_HSV_INTERPOLATION = 2;
    const METHOD_MAX_DIFFERENCE = 3;
    
    
    /**
     * Each methods need to be initialized with a given
     * number of colors. In general, this number is 2.
     * @var Color[] Colors Array
     */
    protected $initialColors = array();
    
    /**
     * ColorLut constructor
     * @param array $initialColors An array of Color
     */
    public function __construct($initialColors) {
        $this->initialColors = $initialColors;
    }
    
    /**
     * This method is initialized with the two first color
     * of $initialColors
     * @param int $nbColors Length of the ColorRgb Array to return
     * @return ColorRgb[] ColorRgb Array
     */
    public function getColorsArrayByRgbInterpolation($nbColors) {
        $resultColors = array();
        $colorA = $this->initialColors[0]->getColorRgb();
        $colorB = $this->initialColors[1]->getColorRgb();
        $colorAVal = $colorA->getRgbArray();
        $colorBVal = $colorB->getRgbArray();
        
        if($nbColors == 1) {
            return array($colorA);
        }
        
        for($i=0;$i<$nbColors;$i++) {
            $rgbTriplet = array();
            $rgbTriplet[0] = $colorAVal[0] + 
                $i*($colorBVal[0]-$colorAVal[0])/($nbColors-1);
            $rgbTriplet[1] = $colorAVal[1] + 
                $i*($colorBVal[1]-$colorAVal[1])/($nbColors-1);
            $rgbTriplet[2] = $colorAVal[2] + 
                $i*($colorBVal[2]-$colorAVal[2])/($nbColors-1);
            $resultColors[$i] = new ColorRgb(intval($rgbTriplet[0]), 
                intval($rgbTriplet[1]), intval($rgbTriplet[2]));
        }
        
        return $resultColors;
    }
    
    /**
     * This method is initialized with the two first color
     * of $initialColors
     * @param int $nbColors Length of the ColorRgb Array to return
     * @param bool $wideHueInterpolation Is interpolation of hue value must be done on the longest path ?
     * @return ColorRgb[] ColorRgb Array
     */
    public function getColorsArrayByHsvInterpolation($nbColors, $wideHueInterpolation = true) {
        $resultColors = array();
        $colorA = $this->initialColors[0]->getColorHsv();
        $colorB = $this->initialColors[1]->getColorHsv();
        $colorAVal = $colorA->getHsvArray();
        $colorBVal = $colorB->getHsvArray();
        
        if($nbColors == 1) {
            return array($colorA);
        }
        
        for($i=0;$i<$nbColors;$i++) {
            $hsvTriplet = array();
            if( (abs($colorBVal[0]-$colorAVal[0]) >= 180 && 
                $wideHueInterpolation)
                || (abs($colorBVal[0]-$colorAVal[0]) < 180 && 
                !$wideHueInterpolation)) {
                $hsvTriplet[0] = $colorAVal[0] + 
                    $i*($colorBVal[0]-$colorAVal[0])/($nbColors-1);
            } else {
                $hsvTriplet[0] = $colorAVal[0] + 
                    $i*(($colorBVal[0]-$colorAVal[0])-360.0)/($nbColors-1);
            }
                if($hsvTriplet[0] < 0.0) {$hsvTriplet[0] += 360.0;}
                if($hsvTriplet[0] >= 360.0) {$hsvTriplet[0] -= 360;}
            $hsvTriplet[1] = $colorAVal[1] + 
                $i*($colorBVal[1]-$colorAVal[1])/($nbColors-1);
            $hsvTriplet[2] = $colorAVal[2] + 
                $i*($colorBVal[2]-$colorAVal[2])/($nbColors-1);
            $resultColors[$i] = new ColorHsv(floatval($hsvTriplet[0]), 
                floatval($hsvTriplet[1]), floatval($hsvTriplet[2]));
        }

        
        
        return $resultColors;
    }
    
    /**
     * This method is initialized with the first color
     * of $initialColors
     * Saturation and Value stay constant
     * This is an appropriate methode for discrete value
     * Result are best when Value is high
     * @param int $nbColors Length of the ColorRgb Array to return
     * @return ColorHsv[] ColorRgb Array
     */
    public function getColorsHsvArrayWithMaxDifference($nbColors) {
        $resultColors = array();
        $colorA = $this->initialColors[0]->getColorHsv();
        $colorAVal = $colorA->getHsvArray();
        
        $deltaHue = 360.0/$nbColors;
        
        if($nbColors == 1) {
            return array($colorA);
        }
        
        for($i=0;$i<$nbColors;$i++) {
            $hue = $colorAVal[0] + $i*$deltaHue;
            if($hue >= 360.0) {$hue -= 360;}
            $resultColors[$i] = new ColorHsv(floatval($hue), 
                floatval($colorAVal[1]), floatval($colorAVal[2]));
        }
        
        
        return $resultColors;
        
    }
    
    /**
     * @param integer $method Method name constant as define in this class
     * @return Color[] 
     */
    public function getColorsByWellKnownMethod($method,$nbColors, 
            $wideHueInterpolation = false) {
        switch($method) {
        case ColorLut::METHOD_RGB_INTERPOLATION :
            $colors = $this->getColorsArrayByRgbInterpolation($nbColors);
            break;
        case ColorLut::METHOD_HSV_INTERPOLATION :
            $colors = $this->getColorsArrayByHsvInterpolation($nbColors, 
                $wideHueInterpolation);
            break;
        case ColorLut::METHOD_MAX_DIFFERENCE :
           $colors = $this->getColorsHsvArrayWithMaxDifference($nbColors);
            break;
        }
        
        return $colors;
    }
    
}

?>