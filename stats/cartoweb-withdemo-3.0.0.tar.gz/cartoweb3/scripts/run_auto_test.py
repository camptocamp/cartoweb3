#!/usr/bin/python

#
# This script makes a checkout of cartoweb cvs, and launches the unit tests.
# If no update of cvs was done, it does not run the tests.
#
# The tests are launched inside a chroot environment, using the dchroot command
# In case of a test failure, an email is sent to a specified address.

# Configuration: change to match your environment
DISABLING_FILE = "/tmp/auto_test_disabled"
EMAIL = "sylvain.pasche@camptocamp.com"
DCHROOT_NAME = "geodatenportal"
PHP5_PATH = "/usr/lib/cgi-bin/php5-c2cms"
TEST_PATH = "/home/sypasche/public_html/cartoweb3/auto_test/cartoweb3/tests/phpunit.php"

module_name = "cartoweb3"

import commands, sys, os, os.path

def is_updated():

    out = commands.getoutput('cd %s;cvs update -dP' % module_name)
    #print "__%s__" % out
    for l in out.split("\n"):
        #if l.startswith("U") or l.startswith("P"):
        if not l.startswith("cvs server"):
            return 1
        #print "LINE", l
    return 0


if __name__ == '__main__':

    if os.path.isfile(DISABLING_FILE):
        print "auto test are disabled, remove %s to activate" % DISABLING_FILE
        sys.exit()

    if 1:
     if not is_updated():
        print "no update"
        sys.exit()

    #sys.exit()

    (status, output) = commands.getstatusoutput('dchroot -c %s %s %s AllTests' % (DCHROOT_NAME, PHP5_PATH, TEST_PATH))


    print "Status", status
    print "output", output

    # to debug:
    #status = 1

    if status != 0:
        #print "Error:", output
        f = os.popen('mail -s auto_test_report %s' % EMAIL, 'w')

        output = "This is an error report from the automatic cartoweb testing. \n" + \
                 " Please investigate the problem, and remove the file %s on this host \n\n %s" % \
                 (DISABLING_FILE, output)
        
        f.write(output)
        f.close()
        open(DISABLING_FILE, 'w').write("")


