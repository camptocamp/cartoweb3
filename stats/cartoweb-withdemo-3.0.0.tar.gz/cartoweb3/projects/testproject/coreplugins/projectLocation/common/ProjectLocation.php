<?
/**
 * @package Tests
 * @version $Id: ProjectLocation.php,v 1.3 2005/02/21 11:42:21 sypasche Exp $
 */

/**
 * @package Tests
 */
class ProjectLocationRequest extends Serializable {

    public $locationRequest;
    public $projectRequest;

    /**
     * @see Serializable::unserialize()
     */
    public function unserialize($struct) {

        $this->locationRequest = self::unserializeObject($struct, 'locationRequest');        
        $this->projectRequest = self::unserializeValue($struct, 'projectRequest');
    }
}

/**
 * @package Tests
 */
class ProjectLocationResult extends Serializable {

    public $locationResult;
    public $projectResult;

    /**
     * @see Serializable::unserialize()
     */
    public function unserialize($struct) {
        
        $this->locationResult = self::unserializeObject($struct, 'locationResult');        
        $this->projectResult = self::unserializeValue($struct, 'projectResult');
    }
}

?>