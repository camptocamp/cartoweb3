<?php
/**
* @package tests
*/
/**
* @package tests
*/
class mama
{}

?>