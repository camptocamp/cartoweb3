<?php

/** @package tests */
/** test function */
function test_445820 ($val = array("1","2",'3' => 4), $string, $my_array)
{
}
?>
