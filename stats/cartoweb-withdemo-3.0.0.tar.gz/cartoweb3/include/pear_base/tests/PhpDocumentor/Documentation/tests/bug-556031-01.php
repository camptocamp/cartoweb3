<?php
/**
* @package tests
*/
/**
* 
*/
class baby extends mama
{
	var $oopsieindexing;
}
?>