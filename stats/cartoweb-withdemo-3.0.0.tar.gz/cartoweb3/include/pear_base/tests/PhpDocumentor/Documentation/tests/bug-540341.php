<?php
/** @package tests */
/** @package tests */
class bug540341
{
	function get_header2($atate)
	{
		$header2 .= '\'>First Page</a></td>';
	}
}
?>
