<?php
/**
* @package tests
*/
/**
* @package tests
* @see b553607_Parser
*/
class b553607_Parser
{}
?>