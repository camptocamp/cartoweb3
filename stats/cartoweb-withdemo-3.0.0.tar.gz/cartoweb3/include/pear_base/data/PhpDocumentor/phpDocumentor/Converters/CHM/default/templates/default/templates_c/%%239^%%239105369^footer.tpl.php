<?php /* Smarty version 2.6.0, created on 2003-12-18 01:55:30
         compiled from footer.tpl */ ?>
<?php if (! $this->_tpl_vars['index']): ?>
	<div id="credit">
		<hr>
		Documentation generated on <?php echo $this->_tpl_vars['date']; ?>
 by <a href="<?php echo $this->_tpl_vars['phpdocwebsite']; ?>
" target="_blank">phpDocumentor <?php echo $this->_tpl_vars['phpdocversion']; ?>
</a>
	</div>
<?php endif; ?>
</body>
</html>