<?php
/**
 * @package Htdocs
 * @version $Id: info.php,v 1.2 2004/10/01 11:43:49 yves Exp $
 */

phpinfo();

?>
