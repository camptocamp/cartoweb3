<?php
/** @package tests */
/** 
* blah blah short description 
* blah blah long description 
* @see CONSTANT2 
*/ 
define(CONSTANT1, 1); 

/** 
* blah blah short description 
* blah blah long description 
* @see CONSTANT1 
*/ 
define(CONSTANT2, 2); 
?>