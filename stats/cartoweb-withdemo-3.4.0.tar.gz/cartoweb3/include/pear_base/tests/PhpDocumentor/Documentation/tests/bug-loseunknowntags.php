<?php
/** @package tests */
/**
* I'm a odd test case
* the @ sign is my friend
* @ at teh beggining of a line
* @package tests
*/
class test
{
}

/**
* tags demonstration, but this @version tag is ignored
* @foobar this is silly
* @author this tag is parsed
* @package tests
*/
class test2
{
}
?>
