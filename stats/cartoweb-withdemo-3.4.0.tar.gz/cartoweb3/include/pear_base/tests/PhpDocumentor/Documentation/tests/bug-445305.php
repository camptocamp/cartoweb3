<?php
/** @package tests */
/**
* @param String $foo A string to use in
* a function, if you
* really want to.
*/
function test_445305 ($foo)
{
}
