<?php
/** 
* page-level stuff
* @author test @
* @package tests
*/ 
/** 
* Debug include file 
* @author test @
* @see Debug 
*/ 
require_once(MLIB_INCLUDE_PATH.'/Debug.php'); 
?>