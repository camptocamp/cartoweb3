<?php

/** @package tests */
/** tests */
function test_escape()
{
	if (('"'==$char || "'"==$char) && ($char == $enclosed_by || ""==$enclosed_by) && (0==$i || ($i>0 && "\\"!=$code[$i-1]))) {
	}
}

function test_escape2()
{
}
?>
