CREATE TABLE `temp` (
    `username` varchar(150) NOT NULL default '',
    `password` varchar(200) NOT NULL default ''
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
